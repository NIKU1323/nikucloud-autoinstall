#!/bin/bash
echo "📡 Menu XRAY"
