#!/bin/bash
echo "🐉 Menu TROJAN"
