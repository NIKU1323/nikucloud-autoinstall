#!/bin/bash
echo "🔧 Installing SSH VPN Menu..."
# Tambahkan isi instalasi SSH VPN full di sini
