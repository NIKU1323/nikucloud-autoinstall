#!/bin/bash
echo "🔐 Memulai install SSL untuk domain..."
# Tambahkan pengecekan domain dan certbot di sini
